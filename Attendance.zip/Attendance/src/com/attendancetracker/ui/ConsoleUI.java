/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.attendancetracker.ui;

/**
 *
 * @author sulto
 */
import com.attendancetracker.auth.AuthManager;
import com.attendancetracker.network.AttendanceClient;

import java.util.Scanner;

public class ConsoleUI {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Smart Attendance Tracker ===");
        System.out.print("Enter your ID: ");
        String studentId = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // Authenticate the student
        if (!AuthManager.authenticate(studentId, password)) {
            System.out.println("Authentication failed. Exiting.");
            return;
        }

        // Check if the user is a teacher or a student
        if (AuthManager.isTeacher(studentId)) {
            System.out.println("Welcome Teacher. Start the server from AttendanceServer.java");
        } else {
            // Prompt the student for the attendance code
            System.out.print("Enter today's attendance code: ");
            String code = scanner.nextLine();

            // Mark attendance for the student
            AttendanceClient.startClient(studentId, code);
        }
    }
}
