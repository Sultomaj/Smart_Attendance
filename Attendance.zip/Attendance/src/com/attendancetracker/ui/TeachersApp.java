package com.attendancetracker.ui;

import com.attendancetracker.data.AttendanceRecord;
import com.attendancetracker.data.DatabaseManager;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.TableColumn;

import java.io.File;
import java.io.FileWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class TeachersApp extends Application {

    private Stage primaryStage;
    private BorderPane root;
    private DatePicker startDatePicker;
    private DatePicker endDatePicker;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        root = new BorderPane();
        showLoginScreen();
        primaryStage.setTitle("Teacher Dashboard - Smart Attendance Tracker");
        primaryStage.setScene(new Scene(root, 700, 550));
        primaryStage.show();
    }

    private void showLoginScreen() {
        VBox loginBox = new VBox(10);
        loginBox.setPadding(new Insets(20));

        TextField idField = new TextField();
        idField.setPromptText("Enter teacher ID");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");

        Button loginBtn = new Button("Login");
        loginBtn.setOnAction(e -> {
            String id = idField.getText().trim();
            String pw = passwordField.getText().trim();
            if (DatabaseManager.validateStudentCredentials(id, pw)
                    && "teacher".equals(DatabaseManager.getUserRole(id))) {
                showTeacherDashboard();
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid credentials.");
            }
        });

        loginBox.getChildren().addAll(new Label("Teacher Login"), idField, passwordField, loginBtn);
        root.setCenter(loginBox);
    }

    private void showTeacherDashboard() {
        // Date filter controls
        HBox filterBox = new HBox(10);
        filterBox.setPadding(new Insets(10));
        startDatePicker = new DatePicker();
        startDatePicker.setPromptText("Start Date");
        endDatePicker = new DatePicker();
        endDatePicker.setPromptText("End Date");
        Button applyFilterBtn = new Button("Apply Date Filter");
        applyFilterBtn.setOnAction(e -> refreshTabs());
        filterBox.getChildren().addAll(new Label("Filter by Date:"), startDatePicker, endDatePicker, applyFilterBtn);

        // Tabs for day and week
        TabPane tabPane = new TabPane();
        Tab dailyTab = new Tab("Daily Summary");
        Tab weeklyTab = new Tab("Weekly Summary");
        tabPane.getTabs().addAll(dailyTab, weeklyTab);
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Initial load of content
        dailyTab.setContent(createGroupedTable("day"));
        weeklyTab.setContent(createGroupedTable("week"));

        // Export button
        Button exportBtn = new Button("Export as CSV");
        exportBtn.setOnAction(e -> exportAttendanceToCSV());

        VBox layout = new VBox(10, filterBox, tabPane, exportBtn);
        layout.setPadding(new Insets(10));
        root.setCenter(layout);
    }

    private void refreshTabs() {
        // Recreate dashboard to refresh tables with updated date filters
        showTeacherDashboard();
    }

    private VBox createGroupedTable(String type) {
        TableView<AttendanceRecord> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<AttendanceRecord, String> idCol = new TableColumn<>("Student ID");
        idCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStudentId()));

        TableColumn<AttendanceRecord, String> timeCol = new TableColumn<>("Timestamp");
        timeCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTimestamp().toString()));

        TableColumn<AttendanceRecord, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCode()));

        table.getColumns().addAll(idCol, timeCol, codeCol);

        // Determine date filters
        LocalDate start = startDatePicker.getValue();
        LocalDate end = endDatePicker.getValue();
        List<AttendanceRecord> records;
        if (start != null && end != null) {
            records = DatabaseManager.getAttendanceRecordsBetween(start, end);
        } else {
            records = DatabaseManager.getAllAttendanceRecords();
        }

        ObservableList<AttendanceRecord> data = FXCollections.observableArrayList();
        if ("day".equals(type)) {
            Map<LocalDate, List<AttendanceRecord>> grouped;
            if (start != null && end != null) {
                grouped = DatabaseManager.groupAttendanceByDay(records, start, end);
            } else {
                grouped = DatabaseManager.groupAttendanceByDay(records);
            }
            grouped.values().forEach(data::addAll);
        } else {
            Map<String, List<AttendanceRecord>> grouped;
            if (start != null && end != null) {
                grouped = DatabaseManager.groupAttendanceByWeek(records, start, end);
            } else {
                grouped = DatabaseManager.groupAttendanceByWeek(records);
            }
            grouped.values().forEach(data::addAll);
        }

        table.setItems(data);
        return new VBox(table);
    }

    private void exportAttendanceToCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Attendance Summary");
        fileChooser.setInitialFileName("attendance_summary.csv");
        File file = fileChooser.showSaveDialog(primaryStage);

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Student ID,Timestamp,Code\n");
                LocalDate start = startDatePicker.getValue();
                LocalDate end = endDatePicker.getValue();
                List<AttendanceRecord> records;
                if (start != null && end != null) {
                    records = DatabaseManager.getAttendanceRecordsBetween(start, end);
                } else {
                    records = DatabaseManager.getAllAttendanceRecords();
                }
                for (AttendanceRecord record : records) {
                    writer.write(String.format("%s,%s,%s\n",
                            record.getStudentId(),
                            record.getTimestamp(),
                            record.getCode()));
                }
                showAlert(Alert.AlertType.INFORMATION, "Success", "Attendance exported successfully.");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Export Failed", "Could not export file.");
            }
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
