package com.attendancetracker.ui;

import com.attendancetracker.data.DatabaseManager;
import com.attendancetracker.network.AttendanceClient;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;

public class AttendanceApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        TextField studentIdField = new TextField();
        studentIdField.setPromptText("Enter your ID");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");

        TextField attendanceCodeField = new TextField();
        attendanceCodeField.setPromptText("Enter today's attendance code");

        Button submitButton = new Button("Submit");
        //Button viewHistoryButton = new Button("View My Attendance");
        //Button viewSummaryButton = new Button("Teacher Summary");

        VBox vbox = new VBox(10);
        vbox.setStyle("-fx-padding: 20;");
        vbox.getChildren().addAll(
                studentIdField,
                passwordField,
                attendanceCodeField,
                submitButton
        //viewHistoryButton,
        // viewSummaryButton
        );

        // Handle attendance submission
        submitButton.setOnAction(e -> {
            String studentId = studentIdField.getText().trim();
            String password = passwordField.getText().trim();
            String code = attendanceCodeField.getText().trim();

            if (!DatabaseManager.validateStudentCredentials(studentId, password)) {
                showAlert(Alert.AlertType.ERROR, "Invalid Credentials", "Incorrect ID or password.");
                return;
            }

            String role = DatabaseManager.getUserRole(studentId);
            if ("teacher".equals(role)) {
                showAlert(Alert.AlertType.INFORMATION, "Teacher Mode",
                        "Welcome Teacher. Please start the server (run AttendanceServer.java).");
            } else {
                String response = AttendanceClient.startClient(studentId, code);
                showAlert(Alert.AlertType.INFORMATION, "Attendance Response", response);
            }
        });

        // Handle student viewing their own attendance history
//        viewHistoryButton.setOnAction(e -> {
//            String studentId = studentIdField.getText().trim();
//            String password = passwordField.getText().trim();
//
//            if (!DatabaseManager.validateStudentCredentials(studentId, password)) {
//                showAlert(Alert.AlertType.ERROR, "Invalid Credentials", "Incorrect ID or password.");
//                return;
//            }
//
//            List<String> history = DatabaseManager.getAttendanceHistory(studentId);
//            StringBuilder historyMsg = new StringBuilder("Your Attendance History:\n");
//            for (String record : history) {
//                historyMsg.append(record).append("\n");
//            }
//            showAlert(Alert.AlertType.INFORMATION, "Attendance History", historyMsg.toString());
//        });
//
//        // Handle teacher viewing all attendance records
//        viewSummaryButton.setOnAction(e -> {
//            String studentId = studentIdField.getText().trim();
//            String password = passwordField.getText().trim();
//
//            if (!DatabaseManager.validateStudentCredentials(studentId, password)) {
//                showAlert(Alert.AlertType.ERROR, "Invalid Credentials", "Incorrect ID or password.");
//                return;
//            }
//            String role = DatabaseManager.getUserRole(studentId);
//            if (!"teacher".equals(role)) {
//                showAlert(Alert.AlertType.WARNING, "Access Denied", "Only teachers can view the summary.");
//                return;
//            }
//
//            List<String> summary = DatabaseManager.getAllAttendanceSummary();
//            StringBuilder summaryMsg = new StringBuilder("Attendance Summary:\n");
//            for (String record : summary) {
//                summaryMsg.append(record).append("\n");
//            }
//            showAlert(Alert.AlertType.INFORMATION, "Summary", summaryMsg.toString());
        // });
        Scene scene = new Scene(vbox, 400, 350);
        primaryStage.setTitle("Smart Attendance Tracker");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
