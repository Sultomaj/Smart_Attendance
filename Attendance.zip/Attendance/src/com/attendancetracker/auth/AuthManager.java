/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.attendancetracker.auth;

/**
 *
 * @author sulto
 */
import java.util.HashMap;
import java.util.Map;

public class AuthManager {
    private static Map<String, String> credentials = new HashMap<>();

    static {
        // Default users (studentId -> password)
        credentials.put("student1", "pass123");
        credentials.put("student2", "pass456");
        credentials.put("teacher", "adminpass");
    }

    public static boolean authenticate(String studentId, String password) {
        return credentials.containsKey(studentId) && credentials.get(studentId).equals(password);
    }

    public static boolean isTeacher(String studentId) {
        return "teacher".equals(studentId);
    }
}

