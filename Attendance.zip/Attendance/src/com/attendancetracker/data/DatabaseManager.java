/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.attendancetracker.data;

import java.sql.*;
import java.util.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:attendance.db";
    private static final DateTimeFormatter DISPLAY_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd 'T' HH:mm");

    static {
        try (Connection conn = DriverManager.getConnection(DB_URL);
                Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS users ("
                    + "id TEXT PRIMARY KEY, "
                    + "password TEXT NOT NULL, "
                    + "role TEXT NOT NULL)");
            stmt.execute("CREATE TABLE IF NOT EXISTS students (id TEXT PRIMARY KEY, name TEXT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS attendance ("
                    + "student_id TEXT, "
                    + "timestamp TEXT, "
                    + "code TEXT, "
                    + "PRIMARY KEY (student_id, code), "
                    + "FOREIGN KEY(student_id) REFERENCES users(id))");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean validateStudentCredentials(String studentId, String password) {
        String query = "SELECT 1 FROM users WHERE id = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void addStudent(Student student) {
        String sql = "INSERT OR IGNORE INTO students (id, name) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, student.getId());
            pstmt.setString(2, student.getName());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void logAttendance(AttendanceRecord record) {
        String sql = "INSERT INTO attendance (student_id, timestamp, code) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, record.getStudentId());
            pstmt.setString(2, record.getTimestamp().toString());
            pstmt.setString(3, record.getCode());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<AttendanceRecord> getAttendanceByStudent(String studentId) {
        List<AttendanceRecord> records = new ArrayList<>();
        String sql = "SELECT timestamp FROM attendance WHERE student_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    records.add(new AttendanceRecord(studentId,
                            LocalDateTime.parse(rs.getString("timestamp"))));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static void printAllStudents() {
        String sql = "SELECT s.id, s.name, u.password FROM students s "
                + "JOIN users u ON s.id = u.id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("=== All Students with Passwords ===");
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String password = rs.getString("password");
                System.out.printf("Student ID: %s, Name: %s, Password: %s%n", id, name, password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void printAllAttendance() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM attendance")) {

            while (rs.next()) {
                LocalDateTime timestamp = LocalDateTime.parse(rs.getString("timestamp"));
                System.out.println("Student ID: " + rs.getString("student_id") + ", Timestamp: " + timestamp.format(DISPLAY_FORMATTER));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addUser(String id, String password, String role) {
        String sql = "INSERT OR IGNORE INTO users (id, password, role) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.setString(2, password);
            pstmt.setString(3, role);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String getUserRole(String id) {
        String query = "SELECT role FROM users WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("role");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean hasMarkedAttendance(String studentId, String code) {
        String sql = "SELECT COUNT(*) FROM attendance WHERE student_id = ? AND code = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, studentId);
            pstmt.setString(2, code);

            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<String> getAttendanceHistory(String studentId) {
        List<String> history = new ArrayList<>();
        String sql = "SELECT timestamp, code FROM attendance WHERE student_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                history.add(LocalDateTime.parse(rs.getString("timestamp")).format(DISPLAY_FORMATTER)
                        + " | Code: " + rs.getString("code"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return history;
    }

    public static List<String> getAllAttendanceSummary() {
        List<String> summary = new ArrayList<>();
        String sql = "SELECT student_id, timestamp, code FROM attendance ORDER BY timestamp DESC";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                summary.add("ID: " + rs.getString("student_id")
                        + " | Time: " + LocalDateTime.parse(rs.getString("timestamp")).format(DISPLAY_FORMATTER)
                        + " | Code: " + rs.getString("code"));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return summary;
    }

    public static List<AttendanceRecord> getAllAttendanceRecords() {
        List<AttendanceRecord> records = new ArrayList<>();
        String query = "SELECT student_id, timestamp, code FROM attendance ORDER BY timestamp DESC";
        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String studentId = rs.getString("student_id");
                LocalDateTime timestamp = LocalDateTime.parse(rs.getString("timestamp"));
                String code = rs.getString("code");

                records.add(new AttendanceRecord(studentId, timestamp, code));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static Map<LocalDate, List<AttendanceRecord>> groupAttendanceByDay(List<AttendanceRecord> records) {
        return records.stream()
                .collect(Collectors.groupingBy(record -> record.getTimestamp().toLocalDate(),
                        TreeMap::new, Collectors.toList()));
    }

    public static Map<LocalDate, List<AttendanceRecord>> groupAttendanceByDay(List<AttendanceRecord> records, LocalDate startDate, LocalDate endDate) {
        return records.stream()
                .filter(record -> {
                    LocalDate date = record.getTimestamp().toLocalDate();
                    return (date.isEqual(startDate) || date.isAfter(startDate)) &&
                           (date.isEqual(endDate) || date.isBefore(endDate));
                })
                .collect(Collectors.groupingBy(record -> record.getTimestamp().toLocalDate(),
                        TreeMap::new, Collectors.toList()));
    }

    public static Map<String, List<AttendanceRecord>> groupAttendanceByWeek(List<AttendanceRecord> records) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' w - yyyy");
        return records.stream()
                .collect(Collectors.groupingBy(
                        record -> record.getTimestamp().format(formatter),
                        TreeMap::new,
                        Collectors.toList()
                ));
    }

    public static Map<String, List<AttendanceRecord>> groupAttendanceByWeek(List<AttendanceRecord> records, LocalDate startDate, LocalDate endDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Week' w - yyyy");
        return records.stream()
                .filter(record -> {
                    LocalDate date = record.getTimestamp().toLocalDate();
                    return (date.isEqual(startDate) || date.isAfter(startDate)) &&
                           (date.isEqual(endDate) || date.isBefore(endDate));
                })
                .collect(Collectors.groupingBy(
                        record -> record.getTimestamp().format(formatter),
                        TreeMap::new,
                        Collectors.toList()
                ));
    }
    public static List<AttendanceRecord> getAttendanceRecordsBetween(LocalDate start, LocalDate end) {
    List<AttendanceRecord> records = new ArrayList<>();
    String query = "SELECT student_id, timestamp, code FROM attendance WHERE timestamp BETWEEN ? AND ? ORDER BY timestamp DESC";
    try (Connection conn = DriverManager.getConnection(DB_URL);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setString(1, start.atStartOfDay().toString());
        stmt.setString(2, end.plusDays(1).atStartOfDay().toString()); // include the full end date

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String studentId = rs.getString("student_id");
                LocalDateTime timestamp = LocalDateTime.parse(rs.getString("timestamp"));
                String code = rs.getString("code");

                records.add(new AttendanceRecord(studentId, timestamp, code));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return records;
}


    public static void main(String[] args) {
          //DatabaseManager.clearAttendanceTable();
    }
}
