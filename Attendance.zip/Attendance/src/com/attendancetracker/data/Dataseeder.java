/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.attendancetracker.data;

/**
 *
 * @author sulto
 */
public class Dataseeder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DatabaseManager.addUser("teacher", "adminpass", "teacher");
        System.out.println("Added teacher user.");

//         String id = "25" + String.format("%04d", i); 
//            String pwd = "pass" + i;          
//            String name = "Student " + i;       
//
//            // Add user credentials for the student
//            DatabaseManager.addUser(id, pwd, "student");
        for (int i = 1; i <= 20; i++) {

            String id = "25" + String.format("%04d", i);
            String pwd = "pass" + i;
            String name = "Student " + i;

            // Add user credentials for the student
            DatabaseManager.addUser(id, pwd, "student");

            // Add student details to the 'students' table
            DatabaseManager.addStudent(new Student(id, name));

            System.out.printf("Seeded %s / %s%n", id, name);
        }

        System.out.println("Database seeding complete.");
    }

}
