/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.attendancetracker.data;

/**
 *
 * @author sulto
 */
import java.time.LocalDateTime;

public class AttendanceRecord {
    private String studentId;
    private LocalDateTime timestamp;
    private String code; // Add this line

    // Updated constructor with code
    public AttendanceRecord(String studentId, LocalDateTime timestamp, String code) {
        this.studentId = studentId;
        this.timestamp = timestamp;
        this.code = code;
    }

    // Overloaded constructor for backward compatibility (optional)
    public AttendanceRecord(String studentId, LocalDateTime timestamp) {
        this(studentId, timestamp, null);
    }

    public String getStudentId() {
        return studentId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getCode() { // Add this getter
        return code;
    }

    public void setCode(String code) { // Optional setter if needed
        this.code = code;
    }
}